from imp import source_from_cache
from django.shortcuts import render
from . import analyser, forms

def index(request):
    """
    FIXME: поля source_file_path, dest_file_path не проходят валидацию;
           поле wordcloud_bgcolor не проходит валидацию, т.к. не Джанговое 
    """
    if request.method == "POST":
        form = forms.AnalyserForm(request.POST)
        if form.is_valid():
            my_analyser = analyser.Analyser(
                source_file_path=r"C:\Users\DDT\Desktop\text_1.txt",
                dest_file_path=r"C:\Users\DDT\Desktop\django_project\my_project\text_analyser\static\text_analyser\wordcloud.png",
                parts_of_speech=form.cleaned_data["parts_of_speech"],
                words_num=form.cleaned_data["words_num"],
                wordcloud_width=form.cleaned_data["wordcloud_width"],
                wordcloud_height=form.cleaned_data["wordcloud_height"],
            )
            return render(request, "text_analyser/result.html", {"wordcloud": "картинка готова"})
        else:
            return render(request, "text_analyser/index.html", {"form": form})
    else:
        form = forms.AnalyserForm()
        return render(request, "text_analyser/index.html", {"form": form})
