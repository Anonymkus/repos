from django import forms


class NewTaskForm(forms.Form):
    task = forms.CharField(label="название")
    radio = forms.NullBooleanField(
        label="Пол",
        widget=forms.Select(
            choices=[
                (True, 'Мужчина'),
                (False, 'Женщина')
                ]
            )
        )
