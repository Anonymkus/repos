from django.shortcuts import render
from datetime import datetime

def index(request):
    now = datetime.now
    print(now.day)
    return render(request,
        "my_app/index.html", 
        {"is_new_year": now.day == 1 and now.month == 1},
        )
