from imp import source_from_cache
from django.shortcuts import render
from . import analyser, forms

def index(request):
    if request.method == "POST":
        form = forms.AnalyserForm(request.POST)
        if form.is_valid():
            analyser.Analyser(
                source_file_path=form.cleanned_data["source_file_path"],
                dest_file_path=form.cleanned_data["dest_file_path"],
                part_of_speech=form.cleanned_data["part_of_speech"],
                words_num=form.cleanned_data["words_num"],
                wordcloud_width=form.cleanned_data["wordcloud_width"],
                wordcloud_height=form.cleanned_data["wordcloud_height"],
                wordcloud_bgcolor=form.cleanned_data["wordcloud_bgcolor"]
            )
        return render(request, "text_analyser/result.html")
    else:
        form_fields = forms.AnalyserForm()
        return render(request, "text_analyser/index.html", {"form_fields": form_fields})
