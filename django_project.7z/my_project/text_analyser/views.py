from django.shortcuts import render
from . import analyser

def index(request):
    ta = analyser.Analyser()
    return render(request, "text_analyser/index.html")
